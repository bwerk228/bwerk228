package com.minnie.ai;

import android.util.Base64;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

/**
 * Handles data compression for the Minnie AI system
 * Compression is essential for efficient storage of knowledge and ghost files
 */
public class Compression {
    private static final String TAG = "Compression";
    
    // Compression levels
    public static final class COMPRESSION_LEVELS {
        public static final int LOW = 1;
        public static final int MEDIUM = 6;
        public static final int HIGH = 9;
    }
    
    // Cache for compressed data
    private Map<String, String> compressionCache;
    
    public Compression() {
        this.compressionCache = new HashMap<>();
    }
    
    /**
     * Compress data using ZLIB compression and Base64 encoding
     */
    public String compressData(String data) {
        return compressData(data, COMPRESSION_LEVELS.MEDIUM);
    }
    
    /**
     * Compress data with a specified compression level
     */
    public String compressData(String data, int level) {
        if (data == null || data.isEmpty()) {
            return data;
        }
        
        // Generate a cache key for this data
        String cacheKey = generateCacheKey(data);
        
        // Check if this data is already in the cache
        if (compressionCache.containsKey(cacheKey)) {
            return compressionCache.get(cacheKey);
        }
        
        try {
            // Convert the string to bytes
            byte[] input = data.getBytes("UTF-8");
            
            // Create deflater
            Deflater deflater = new Deflater(level);
            deflater.setInput(input);
            deflater.finish();
            
            // Compress the data
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream(input.length);
            byte[] buffer = new byte[1024];
            while (!deflater.finished()) {
                int count = deflater.deflate(buffer);
                outputStream.write(buffer, 0, count);
            }
            outputStream.close();
            
            // Get the compressed data
            byte[] output = outputStream.toByteArray();
            
            // Base64 encode for storage
            String compressedData = Base64.encodeToString(output, Base64.DEFAULT);
            
            // Store in cache for future use
            compressionCache.put(cacheKey, compressedData);
            
            // Return the compressed data
            return compressedData;
        } catch (IOException e) {
            Log.e(TAG, "Error compressing data: " + e.getMessage());
            return data; // Return original data if compression fails
        }
    }
    
    /**
     * Decompress data that was compressed with compressData
     */
    public String decompressData(String compressedData) {
        return decompressData(compressedData, COMPRESSION_LEVELS.MEDIUM);
    }
    
    /**
     * Decompress data with a specified compression level
     */
    public String decompressData(String compressedData, int level) {
        if (compressedData == null || compressedData.isEmpty()) {
            return compressedData;
        }
        
        try {
            // Base64 decode
            byte[] input = Base64.decode(compressedData, Base64.DEFAULT);
            
            // Create inflater
            Inflater inflater = new Inflater();
            inflater.setInput(input);
            
            // Decompress the data
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream(input.length);
            byte[] buffer = new byte[1024];
            while (!inflater.finished()) {
                int count = inflater.inflate(buffer);
                outputStream.write(buffer, 0, count);
            }
            outputStream.close();
            
            // Get the decompressed data
            byte[] output = outputStream.toByteArray();
            
            // Convert back to string
            return new String(output, "UTF-8");
        } catch (Exception e) {
            Log.e(TAG, "Error decompressing data: " + e.getMessage());
            return compressedData; // Return compressed data if decompression fails
        }
    }
    
    /**
     * Check if data is compressed by attempting to decode and inflate it
     */
    public boolean isCompressed(String data) {
        if (data == null || data.isEmpty()) {
            return false;
        }
        
        try {
            // Try to Base64 decode
            byte[] decodedData = Base64.decode(data, Base64.DEFAULT);
            
            // Check if the first few bytes match the ZLIB header
            return (decodedData.length > 2 && 
                    (decodedData[0] & 0xFF) == 0x78 &&
                    (decodedData[1] & 0xFF) >= 0x01 &&
                    (decodedData[1] & 0xFF) <= 0x9C);
        } catch (IllegalArgumentException e) {
            // Not Base64 encoded
            return false;
        }
    }
    
    /**
     * Generate a cache key for data to be compressed
     */
    private String generateCacheKey(String data) {
        // Simple hashing function for the cache key
        try {
            int hashCode = data.hashCode();
            return "comp_" + hashCode + "_" + data.length();
        } catch (Exception e) {
            return "comp_" + System.currentTimeMillis();
        }
    }
    
    /**
     * Compress data and store it as a ghost file in the JSON structure
     */
    public void compressAndStoreGhostFile(JsonStructure structure, String content, String type) {
        String compressedContent = compressData(content, COMPRESSION_LEVELS.HIGH);
        structure.createGhostFile(compressedContent, type);
    }
    
    /**
     * Create a compressed representation of system state for backup
     */
    public JSONObject createCompressedSystemState(JsonStructure structure) {
        try {
            JSONObject systemState = new JSONObject();
            
            // Get the full JSON structure
            String structureString = structure.getStructure().toString();
            
            // Compress it
            String compressedStructure = compressData(structureString, COMPRESSION_LEVELS.HIGH);
            
            // Store in the system state
            systemState.put("structure", compressedStructure);
            systemState.put("timestamp", System.currentTimeMillis() / 1000);
            systemState.put("compressed", true);
            systemState.put("compression_level", COMPRESSION_LEVELS.HIGH);
            
            return systemState;
        } catch (JSONException e) {
            Log.e(TAG, "Error creating compressed system state: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Clear the compression cache to free memory
     */
    public void clearCache() {
        compressionCache.clear();
    }
    
    /**
     * Get statistics about the compression cache
     */
    public JSONObject getCacheStats() {
        try {
            JSONObject stats = new JSONObject();
            stats.put("cache_entries", compressionCache.size());
            
            int totalOriginalSize = 0;
            int totalCompressedSize = 0;
            
            for (Map.Entry<String, String> entry : compressionCache.entrySet()) {
                String key = entry.getKey();
                String value = entry.getValue();
                
                // Extract the original length from the key
                String[] parts = key.split("_");
                if (parts.length >= 3) {
                    try {
                        int originalLength = Integer.parseInt(parts[2]);
                        totalOriginalSize += originalLength;
                        totalCompressedSize += value.length();
                    } catch (NumberFormatException e) {
                        // Ignore
                    }
                }
            }
            
            stats.put("total_original_bytes", totalOriginalSize);
            stats.put("total_compressed_bytes", totalCompressedSize);
            
            double compressionRatio = 0.0;
            if (totalOriginalSize > 0) {
                compressionRatio = (double) totalOriginalSize / totalCompressedSize;
            }
            
            stats.put("compression_ratio", compressionRatio);
            
            return stats;
        } catch (JSONException e) {
            Log.e(TAG, "Error generating cache stats: " + e.getMessage());
            return null;
        }
    }
}
