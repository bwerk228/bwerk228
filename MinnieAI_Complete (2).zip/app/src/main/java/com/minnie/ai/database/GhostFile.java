package com.minnie.ai.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Entity class representing a ghost file in the database
 */
@Entity
public class GhostFile {
    @PrimaryKey(autoGenerate = true)
    public int id;
    
    public String content;
    public String type;
    public long created;
}
