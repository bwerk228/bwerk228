package com.minnie.ai.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

/**
 * Data Access Object for SystemState entity
 */
@Dao
public interface SystemStateDao {
    
    @Insert
    void insert(SystemState systemState);
    
    @Query("SELECT * FROM SystemState ORDER BY timestamp DESC LIMIT 1")
    SystemState getLatestSystemState();
    
    @Query("DELETE FROM SystemState WHERE id NOT IN (SELECT id FROM SystemState ORDER BY timestamp DESC LIMIT 5)")
    void keepOnlyRecentStates();
}
