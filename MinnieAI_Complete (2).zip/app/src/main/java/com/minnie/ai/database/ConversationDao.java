package com.minnie.ai.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

/**
 * Data Access Object for Conversation entity
 */
@Dao
public interface ConversationDao {
    
    @Insert
    void insert(Conversation conversation);
    
    @Query("SELECT * FROM Conversation ORDER BY timestamp DESC")
    List<Conversation> getAllConversations();
    
    @Query("DELETE FROM Conversation WHERE timestamp < :thresholdTime")
    void deleteOldConversations(long thresholdTime);
}
