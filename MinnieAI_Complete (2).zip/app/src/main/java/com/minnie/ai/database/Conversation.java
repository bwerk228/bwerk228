package com.minnie.ai.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Entity class representing a conversation entry in the database
 */
@Entity
public class Conversation {
    @PrimaryKey(autoGenerate = true)
    public int id;
    
    public String userInput;
    public String systemResponse;
    public long timestamp;
    public double contextComplexity;
    public double cognitiveLoad;
}
