package com.minnie.ai.database;

import android.content.Context;

import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * Manager class that handles all database operations
 */
public class DatabaseManager {
    private static final long CONVERSATION_RETENTION_PERIOD = 7 * 24 * 60 * 60 * 1000; // 7 days
    private static final long GHOST_FILE_RETENTION_PERIOD = 24 * 60 * 60 * 1000; // 1 day
    private static final long KNOWLEDGE_CACHE_RETENTION_PERIOD = 30 * 24 * 60 * 60 * 1000; // 30 days
    
    private final AppDatabase database;
    private final Executor executor;
    
    public DatabaseManager(Context context) {
        database = AppDatabase.getInstance(context);
        executor = Executors.newFixedThreadPool(4);
    }
    
    // Conversation methods
    public void saveConversation(String userInput, String systemResponse, double contextComplexity, double cognitiveLoad) {
        executor.execute(() -> {
            Conversation conversation = new Conversation();
            conversation.userInput = userInput;
            conversation.systemResponse = systemResponse;
            conversation.timestamp = System.currentTimeMillis();
            conversation.contextComplexity = contextComplexity;
            conversation.cognitiveLoad = cognitiveLoad;
            
            database.conversationDao().insert(conversation);
        });
    }
    
    public void getConversationHistory(Callback<List<Conversation>> callback) {
        executor.execute(() -> {
            List<Conversation> conversations = database.conversationDao().getAllConversations();
            callback.onResult(conversations);
        });
    }
    
    // Ghost File methods
    public void saveGhostFile(String content, String type) {
        executor.execute(() -> {
            GhostFile ghostFile = new GhostFile();
            ghostFile.content = content;
            ghostFile.type = type;
            ghostFile.created = System.currentTimeMillis();
            
            database.ghostFileDao().insert(ghostFile);
        });
    }
    
    public void getGhostFilesByType(String type, Callback<List<GhostFile>> callback) {
        executor.execute(() -> {
            List<GhostFile> ghostFiles = database.ghostFileDao().getGhostFilesByType(type);
            callback.onResult(ghostFiles);
        });
    }
    
    // Knowledge Cache methods
    public void saveKnowledgeCache(String domain, String data, int compressionLevel) {
        executor.execute(() -> {
            KnowledgeCache cache = new KnowledgeCache();
            cache.domain = domain;
            cache.data = data;
            cache.compressionLevel = compressionLevel;
            cache.lastAccessed = System.currentTimeMillis();
            
            database.knowledgeCacheDao().insert(cache);
        });
    }
    
    public void getKnowledgeCache(String domain, Callback<KnowledgeCache> callback) {
        executor.execute(() -> {
            KnowledgeCache cache = database.knowledgeCacheDao().getKnowledgeCache(domain);
            callback.onResult(cache);
        });
    }
    
    public void updateKnowledgeCacheAccess(String domain) {
        executor.execute(() -> {
            database.knowledgeCacheDao().updateLastAccessed(domain, System.currentTimeMillis());
        });
    }
    
    // System State methods
    public void saveSystemState(String jsonStructure) {
        executor.execute(() -> {
            SystemState state = new SystemState();
            state.jsonStructure = jsonStructure;
            state.timestamp = System.currentTimeMillis();
            
            database.systemStateDao().insert(state);
            database.systemStateDao().keepOnlyRecentStates();
        });
    }
    
    public void getLatestSystemState(Callback<SystemState> callback) {
        executor.execute(() -> {
            SystemState state = database.systemStateDao().getLatestSystemState();
            callback.onResult(state);
        });
    }
    
    // Maintenance methods
    public void performMaintenance() {
        executor.execute(() -> {
            long currentTime = System.currentTimeMillis();
            
            // Delete old conversations
            database.conversationDao().deleteOldConversations(currentTime - CONVERSATION_RETENTION_PERIOD);
            
            // Delete old ghost files
            database.ghostFileDao().deleteOldGhostFiles(currentTime - GHOST_FILE_RETENTION_PERIOD);
            
            // Delete old knowledge caches
            database.knowledgeCacheDao().deleteOldCaches(currentTime - KNOWLEDGE_CACHE_RETENTION_PERIOD);
        });
    }
    
    // Callback interface for async operations
    public interface Callback<T> {
        void onResult(T result);
    }
}
