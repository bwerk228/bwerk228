package com.minnie.ai;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Adapter for displaying conversation items in a RecyclerView
 */
public class ConversationAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int VIEW_TYPE_USER = 1;
    private static final int VIEW_TYPE_SYSTEM = 2;
    
    private final List<MainActivity.ConversationItem> conversations;
    private final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
    
    public ConversationAdapter(List<MainActivity.ConversationItem> conversations) {
        this.conversations = conversations;
    }
    
    @Override
    public int getItemViewType(int position) {
        MainActivity.ConversationItem item = conversations.get(position);
        return item.isUserMessage() ? VIEW_TYPE_USER : VIEW_TYPE_SYSTEM;
    }
    
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        
        if (viewType == VIEW_TYPE_USER) {
            View view = inflater.inflate(R.layout.item_user_message, parent, false);
            return new UserMessageViewHolder(view);
        } else {
            View view = inflater.inflate(R.layout.item_system_message, parent, false);
            return new SystemMessageViewHolder(view);
        }
    }
    
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        MainActivity.ConversationItem item = conversations.get(position);
        String time = timeFormat.format(new Date(item.getTimestamp()));
        
        if (holder instanceof UserMessageViewHolder) {
            UserMessageViewHolder userHolder = (UserMessageViewHolder) holder;
            userHolder.messageText.setText(item.getUserInput());
            userHolder.timeText.setText(time);
        } else if (holder instanceof SystemMessageViewHolder) {
            SystemMessageViewHolder systemHolder = (SystemMessageViewHolder) holder;
            systemHolder.messageText.setText(item.getSystemResponse());
            systemHolder.timeText.setText(time);
        }
    }
    
    @Override
    public int getItemCount() {
        return conversations.size();
    }
    
    // ViewHolder for user messages
    static class UserMessageViewHolder extends RecyclerView.ViewHolder {
        TextView messageText;
        TextView timeText;
        
        UserMessageViewHolder(@NonNull View itemView) {
            super(itemView);
            messageText = itemView.findViewById(R.id.user_message_text);
            timeText = itemView.findViewById(R.id.user_message_time);
        }
    }
    
    // ViewHolder for system messages
    static class SystemMessageViewHolder extends RecyclerView.ViewHolder {
        TextView messageText;
        TextView timeText;
        
        SystemMessageViewHolder(@NonNull View itemView) {
            super(itemView);
            messageText = itemView.findViewById(R.id.system_message_text);
            timeText = itemView.findViewById(R.id.system_message_time);
        }
    }
}
