package com.minnie.ai;

import android.content.Context;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

/**
 * Manages knowledge domains for the Minnie AI system
 * Knowledge is structured in JSON format and loaded locally
 */
public class KnowledgeBase {
    private static final String TAG = "KnowledgeBase";
    private static final String DOMAIN_PATH = "knowledge_files/domains/";
    
    private Context context;
    private Map<String, JSONObject> loadedDomains;
    private JSONObject knowledgeStructure;
    private Compression compression;
    
    public KnowledgeBase(Context context) {
        this.context = context;
        this.loadedDomains = new HashMap<>();
        this.knowledgeStructure = new JSONObject();
        this.compression = new Compression();
        
        try {
            // Initialize the knowledge structure
            this.knowledgeStructure.put("domains", new JSONObject());
            this.knowledgeStructure.put("stats", new JSONObject());
        } catch (JSONException e) {
            Log.e(TAG, "Error initializing knowledge structure: " + e.getMessage());
        }
    }
    
    /**
     * Initialize the knowledge base by loading core domains
     */
    public void initialize() {
        String[] coreDomains = {"arts", "history", "science", "technology"};
        
        for (String domain : coreDomains) {
            loadDomain(domain);
        }
        
        try {
            // Update stats in the knowledge structure
            JSONObject stats = knowledgeStructure.getJSONObject("stats");
            stats.put("domains_loaded", loadedDomains.size());
            stats.put("last_update", System.currentTimeMillis() / 1000);
        } catch (JSONException e) {
            Log.e(TAG, "Error updating knowledge stats: " + e.getMessage());
        }
    }
    
    /**
     * Load a specific knowledge domain
     */
    public boolean loadDomain(String domainName) {
        String fileName = domainName + ".json";
        String filePath = DOMAIN_PATH + fileName;
        
        try {
            // Read the JSON file from assets
            InputStream is = context.getAssets().open(filePath);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            String line;
            
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
            
            // Parse the JSON content
            JSONObject domainData = new JSONObject(sb.toString());
            
            // Store in the loaded domains map
            loadedDomains.put(domainName, domainData);
            
            // Update the knowledge structure
            try {
                JSONObject domains = knowledgeStructure.getJSONObject("domains");
                domains.put(domainName, domainData);
            } catch (JSONException e) {
                Log.e(TAG, "Error updating knowledge structure: " + e.getMessage());
            }
            
            return true;
        } catch (IOException | JSONException e) {
            Log.e(TAG, "Error loading domain " + domainName + ": " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Get knowledge from a specific domain
     */
    public JSONObject getKnowledge(String domainName) {
        if (loadedDomains.containsKey(domainName)) {
            return loadedDomains.get(domainName);
        } else {
            // Try to load the domain if it's not already loaded
            if (loadDomain(domainName)) {
                return loadedDomains.get(domainName);
            }
        }
        
        return null;
    }
    
    /**
     * Get a specific topic within a domain
     */
    public JSONObject getTopic(String domainName, String topicName) {
        try {
            JSONObject domain = getKnowledge(domainName);
            
            if (domain != null && domain.has("topics")) {
                JSONObject topics = domain.getJSONObject("topics");
                
                if (topics.has(topicName)) {
                    return topics.getJSONObject(topicName);
                }
            }
        } catch (JSONException e) {
            Log.e(TAG, "Error getting topic " + topicName + ": " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Search for information across all domains
     */
    public JSONObject searchKnowledge(String query) {
        // This would contain proper search logic
        // For demonstration purposes, return a simple response
        JSONObject result = new JSONObject();
        
        try {
            result.put("query", query);
            result.put("domains_searched", loadedDomains.size());
            result.put("results_found", 0);
            
            // Simple keyword matching for demonstration
            for (Map.Entry<String, JSONObject> entry : loadedDomains.entrySet()) {
                String domainName = entry.getKey();
                JSONObject domain = entry.getValue();
                
                // Check if query is in domain overview
                if (domain.has("overview")) {
                    String overview = domain.getString("overview");
                    if (overview.toLowerCase().contains(query.toLowerCase())) {
                        result.put("results_found", result.getInt("results_found") + 1);
                        result.put("domain_match", domainName);
                        result.put("match_text", overview);
                        break;
                    }
                }
            }
        } catch (JSONException e) {
            Log.e(TAG, "Error searching knowledge: " + e.getMessage());
        }
        
        return result;
    }
    
    /**
     * Get a compressed representation of the knowledge base
     */
    public String getCompressedKnowledge() {
        return compression.compressData(knowledgeStructure.toString());
    }
    
    /**
     * Get the entire knowledge structure
     */
    public JSONObject getKnowledgeStructure() {
        return knowledgeStructure;
    }
}
