package com.minnie.ai;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.minnie.ai.database.DatabaseManager;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private JsonStructure jsonStructure;
    private VoiceRecognition voiceRecognition;
    private ScreenAwareness screenAwareness;
    private DatabaseManager databaseManager;
    
    private EditText userInput;
    private TextView responseText;
    private Button sendButton;
    private Button voiceButton;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // Initialize UI components
        userInput = findViewById(R.id.userInput);
        responseText = findViewById(R.id.responseText);
        sendButton = findViewById(R.id.sendButton);
        voiceButton = findViewById(R.id.voiceButton);
        
        // Initialize the Minnie AI system
        initializeSystem();
        
        // Set up button listeners
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                processUserInput();
            }
        });
        
        voiceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startVoiceRecognition();
            }
        });
    }
    
    private void initializeSystem() {
        // Initialize JSON structure (core component)
        jsonStructure = new JsonStructure(this);
        
        // Initialize voice recognition
        voiceRecognition = new VoiceRecognition(this, jsonStructure);
        
        // Initialize screen awareness
        screenAwareness = new ScreenAwareness(this, jsonStructure);
        
        // Initialize database
        databaseManager = new DatabaseManager(this);
        
        // Load the initial JSON structure
        jsonStructure.loadInitialStructure();
        
        // Update UI
        responseText.setText("Minnie AI initialized and ready!");
    }
    
    private void processUserInput() {
        String input = userInput.getText().toString().trim();
        
        if (input.isEmpty()) {
            Toast.makeText(this, "Please enter some text", Toast.LENGTH_SHORT).show();
            return;
        }
        
        // Process input through the JSON structure
        JSONObject result = jsonStructure.processInput(input);
        
        try {
            // Extract the AI response
            String aiResponse = result.getString("response");
            
            // Update UI
            responseText.setText(aiResponse);
            userInput.setText("");
            
            // Update cognitive parameters
            jsonStructure.updateCognitiveParameters();
            
            // Create ghost file for context retention
            jsonStructure.createGhostFile(input + " | " + aiResponse);
        } catch (JSONException e) {
            responseText.setText("Error processing your input");
            e.printStackTrace();
        }
        
        // Update screen context
        screenAwareness.updateScreenContext();
    }
    
    private void startVoiceRecognition() {
        voiceRecognition.startVoiceRecognition(new VoiceRecognition.VoiceRecognitionCallback() {
            @Override
            public void onVoiceRecognized(String text) {
                userInput.setText(text);
                processUserInput();
            }
            
            @Override
            public void onError(String errorMessage) {
                Toast.makeText(MainActivity.this, errorMessage, Toast.LENGTH_SHORT).show();
            }
        });
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        // Cleanup any resources
        jsonStructure.cleanupGhostFiles();
        databaseManager.close();
    }
}
