package com.minnie.ai;

import android.app.Activity;
import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.WindowManager;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Handles screen awareness functionality with privacy safeguards
 */
public class ScreenAwareness {
    private static final String TAG = "ScreenAwareness";
    
    private final Context context;
    private final ScreenAwarenessCallback callback;
    private int screenWidth;
    private int screenHeight;
    private int statusBarHeight;
    private float screenDensity;
    private boolean isKeyboardVisible = false;
    private int keyboardHeight = 0;
    private String currentFocus = "none";
    private Point lastTouchPoint = new Point(0, 0);
    private long lastInteractionTime = 0;
    
    public interface ScreenAwarenessCallback {
        void onScreenContextUpdated(JSONObject screenContext);
    }
    
    public ScreenAwareness(Context context, ScreenAwarenessCallback callback) {
        this.context = context;
        this.callback = callback;
        initializeScreenMetrics();
    }
    
    private void initializeScreenMetrics() {
        WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        if (windowManager != null) {
            Display display = windowManager.getDefaultDisplay();
            DisplayMetrics metrics = new DisplayMetrics();
            display.getMetrics(metrics);
            
            screenWidth = metrics.widthPixels;
            screenHeight = metrics.heightPixels;
            screenDensity = metrics.density;
            
            // Get status bar height
            int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
            if (resourceId > 0) {
                statusBarHeight = context.getResources().getDimensionPixelSize(resourceId);
            }
        }
    }
    
    public void setupKeyboardVisibilityDetection(Activity activity) {
        final View rootView = activity.findViewById(android.R.id.content);
        rootView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                Rect r = new Rect();
                rootView.getWindowVisibleDisplayFrame(r);
                int screenHeight = rootView.getRootView().getHeight();
                
                // Calculate the height difference between the window visible area and the root view
                int keyboardHeightValue = screenHeight - r.bottom;
                
                // If the height difference is greater than 25% of the screen height, we assume the keyboard is showing
                boolean isKeyboardNowVisible = keyboardHeightValue > screenHeight * 0.25;
                
                if (isKeyboardVisible != isKeyboardNowVisible || keyboardHeight != keyboardHeightValue) {
                    isKeyboardVisible = isKeyboardNowVisible;
                    keyboardHeight = isKeyboardNowVisible ? keyboardHeightValue : 0;
                    updateScreenContext();
                }
            }
        });
    }
    
    public void updateScreenContext() {
        try {
            JSONObject screenContext = new JSONObject();
            
            // Device information (non-identifying)
            JSONObject device = new JSONObject();
            device.put("displayWidth", screenWidth);
            device.put("displayHeight", screenHeight);
            device.put("displayDensity", screenDensity);
            device.put("orientation", context.getResources().getConfiguration().orientation);
            device.put("statusBarHeight", statusBarHeight);
            
            // Safe version information (no device model or specific identifiers)
            device.put("androidApiLevel", Build.VERSION.SDK_INT);
            screenContext.put("device", device);
            
            // User interface state
            JSONObject uiState = new JSONObject();
            uiState.put("keyboardVisible", isKeyboardVisible);
            if (isKeyboardVisible) {
                uiState.put("keyboardHeight", keyboardHeight);
            }
            uiState.put("currentFocus", currentFocus);
            uiState.put("lastTouchX", lastTouchPoint.x);
            uiState.put("lastTouchY", lastTouchPoint.y);
            
            // Privacy-safe time since last interaction (no actual timestamps)
            long timeSinceInteraction = System.currentTimeMillis() - lastInteractionTime;
            String interactionTimeDescription;
            if (timeSinceInteraction < 5000) {
                interactionTimeDescription = "active_now";
            } else if (timeSinceInteraction < 30000) {
                interactionTimeDescription = "recent";
            } else if (timeSinceInteraction < 120000) {
                interactionTimeDescription = "idle";
            } else {
                interactionTimeDescription = "inactive";
            }
            uiState.put("userInteractionState", interactionTimeDescription);
            
            screenContext.put("uiState", uiState);
            
            // Privacy status
            screenContext.put("privacy_status", "safeguarded");
            screenContext.put("status", "success");
            screenContext.put("message", "Screen context processed");
            
            if (callback != null) {
                callback.onScreenContextUpdated(screenContext);
            }
            
            Log.d(TAG, "Screen context updated");
        } catch (JSONException e) {
            Log.e(TAG, "Error creating screen context: " + e.getMessage());
        }
    }
    
    public void handleScreenResize(int width, int height) {
        if (width != screenWidth || height != screenHeight) {
            screenWidth = width;
            screenHeight = height;
            updateScreenContext();
        }
    }
    
    public void handleMouseMovement(int x, int y) {
        lastTouchPoint.x = x;
        lastTouchPoint.y = y;
        lastInteractionTime = System.currentTimeMillis();
        // We don't update on every movement to avoid excessive updates
    }
    
    public void handleUserInteraction() {
        lastInteractionTime = System.currentTimeMillis();
        updateScreenContext();
    }
    
    public void handleElementFocus(String elementId) {
        currentFocus = elementId;
        lastInteractionTime = System.currentTimeMillis();
        updateScreenContext();
    }
    
    /**
     * Adapts the interface to the current screen context.
     * Returns a JSONObject with the suggested adaptations.
     */
    public JSONObject adaptInterfaceToScreen() {
        JSONObject adaptations = new JSONObject();
        try {
            // Font size adaptations based on screen density
            double fontScaleFactor;
            if (screenDensity < 1.5) {
                fontScaleFactor = 0.85;
            } else if (screenDensity < 2.5) {
                fontScaleFactor = 1.0;
            } else if (screenDensity < 3.5) {
                fontScaleFactor = 1.15;
            } else {
                fontScaleFactor = 1.3;
            }
            adaptations.put("fontScaleFactor", fontScaleFactor);
            
            // Layout adaptations based on screen width
            String layoutMode;
            if (screenWidth < 600) {
                layoutMode = "compact";
            } else if (screenWidth < 960) {
                layoutMode = "normal";
            } else {
                layoutMode = "expanded";
            }
            adaptations.put("layoutMode", layoutMode);
            
            // Keyboard adaptations
            if (isKeyboardVisible) {
                adaptations.put("reduceBottomMargin", true);
                adaptations.put("scrollToFocusedElement", true);
            } else {
                adaptations.put("reduceBottomMargin", false);
                adaptations.put("scrollToFocusedElement", false);
            }
            
            // User interaction adaptations
            if ("inactive".equals(getInteractionState())) {
                adaptations.put("showInactivePrompt", true);
            } else {
                adaptations.put("showInactivePrompt", false);
            }
        } catch (JSONException e) {
            Log.e(TAG, "Error creating interface adaptations: " + e.getMessage());
        }
        
        return adaptations;
    }
    
    public String getInteractionState() {
        long timeSinceInteraction = System.currentTimeMillis() - lastInteractionTime;
        if (timeSinceInteraction < 5000) {
            return "active_now";
        } else if (timeSinceInteraction < 30000) {
            return "recent";
        } else if (timeSinceInteraction < 120000) {
            return "idle";
        } else {
            return "inactive";
        }
    }
}
