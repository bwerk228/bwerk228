package com.minnie.ai.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Entity class representing a system state entry in the database
 */
@Entity
public class SystemState {
    @PrimaryKey(autoGenerate = true)
    public int id;
    
    public String jsonStructure;
    public long timestamp;
}
