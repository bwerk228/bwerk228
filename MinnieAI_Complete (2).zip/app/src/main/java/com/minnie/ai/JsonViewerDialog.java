package com.minnie.ai;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;

/**
 * Dialog for displaying JSON structure in a formatted way
 */
public class JsonViewerDialog extends Dialog {
    private final String jsonContent;
    
    public JsonViewerDialog(@NonNull Context context, String jsonContent) {
        super(context);
        this.jsonContent = jsonContent;
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_json_viewer);
        
        setTitle("JSON Structure");
        
        ScrollView scrollView = findViewById(R.id.json_scroll_view);
        TextView jsonTextView = findViewById(R.id.json_text_view);
        Button closeButton = findViewById(R.id.close_button);
        
        // Format JSON for better readability
        String formattedJson = formatJson(jsonContent);
        jsonTextView.setText(formattedJson);
        
        closeButton.setOnClickListener(v -> dismiss());
    }
    
    /**
     * Simple JSON formatter to add line breaks and indentation
     */
    private String formatJson(String json) {
        StringBuilder result = new StringBuilder();
        int indentLevel = 0;
        boolean inQuotes = false;
        
        for (char c : json.toCharArray()) {
            switch (c) {
                case '{':
                case '[':
                    result.append(c);
                    if (!inQuotes) {
                        result.append('\n');
                        indentLevel++;
                        appendIndentation(result, indentLevel);
                    }
                    break;
                case '}':
                case ']':
                    if (!inQuotes) {
                        result.append('\n');
                        indentLevel--;
                        appendIndentation(result, indentLevel);
                    }
                    result.append(c);
                    break;
                case ',':
                    result.append(c);
                    if (!inQuotes) {
                        result.append('\n');
                        appendIndentation(result, indentLevel);
                    }
                    break;
                case ':':
                    result.append(c).append(' ');
                    break;
                case '"':
                    result.append(c);
                    // Check if this quote is escaped
                    boolean escaped = false;
                    int index = result.length() - 2;
                    while (index >= 0 && result.charAt(index) == '\\') {
                        escaped = !escaped;
                        index--;
                    }
                    if (!escaped) {
                        inQuotes = !inQuotes;
                    }
                    break;
                case '\n':
                case '\r':
                case '\t':
                    // Skip these characters in the formatted output if not in quotes
                    if (inQuotes) {
                        result.append(c);
                    }
                    break;
                default:
                    result.append(c);
                    break;
            }
        }
        
        return result.toString();
    }
    
    private void appendIndentation(StringBuilder result, int indentLevel) {
        for (int i = 0; i < indentLevel; i++) {
            result.append("    "); // 4 spaces per indent level
        }
    }
}
