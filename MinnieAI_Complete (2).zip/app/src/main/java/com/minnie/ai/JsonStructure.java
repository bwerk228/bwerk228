package com.minnie.ai;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.minnie.ai.database.DatabaseManager;
import com.minnie.ai.database.SystemState;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.stream.Collectors;

/**
 * Core class that represents the JSON-based framework of Minnie AI.
 * All cognitive functionality is embedded within this structure.
 */
public class JsonStructure {
    private static final String TAG = "JsonStructure";
    private static final String BASE_STRUCTURE_PATH = "json/base_structure.json";
    
    private JSONObject structure;
    private final DatabaseManager databaseManager;
    private final Context context;
    
    // Cognitive parameters
    private double contextWindowSize = 10.0;
    private double priorityRetention = 0.7;
    private double evaluationThreshold = 0.6;
    private double subliminality = 0.3;
    private double perspectiveProximity = 0.8;
    private double conversationComplexity = 0.5;
    private double userResponsiveness = 0.5;
    
    public JsonStructure(Context context, DatabaseManager databaseManager) {
        this.context = context;
        this.databaseManager = databaseManager;
        
        // Try to load the latest structure from the database
        loadFromDatabase();
    }
    
    private void loadFromDatabase() {
        databaseManager.getLatestSystemState(state -> {
            if (state != null) {
                try {
                    structure = new JSONObject(state.jsonStructure);
                    loadParametersFromStructure();
                    Log.d(TAG, "Structure loaded from database");
                } catch (JSONException e) {
                    Log.e(TAG, "Error parsing saved structure: " + e.getMessage());
                    loadFromAssets();
                }
            } else {
                loadFromAssets();
            }
        });
    }
    
    private void loadFromAssets() {
        try {
            InputStream is = context.getAssets().open(BASE_STRUCTURE_PATH);
            String jsonString = new BufferedReader(new InputStreamReader(is))
                    .lines().collect(Collectors.joining("\n"));
            structure = new JSONObject(jsonString);
            loadParametersFromStructure();
            Log.d(TAG, "Structure loaded from assets");
            
            // Save to database
            saveToDatabase();
        } catch (Exception e) {
            Log.e(TAG, "Error loading structure from assets: " + e.getMessage());
            createDefaultStructure();
        }
    }
    
    private void createDefaultStructure() {
        try {
            structure = new JSONObject();
            structure.put("version", "1.0");
            structure.put("system", new JSONObject()
                    .put("name", "Minnie")
                    .put("description", "Self-contained AI system with embedded cognitive processing"));
            
            // Create cognitive parameters
            JSONObject cognitive = new JSONObject();
            cognitive.put("contextWindowSize", contextWindowSize);
            cognitive.put("priorityRetention", priorityRetention);
            cognitive.put("evaluationThreshold", evaluationThreshold);
            cognitive.put("subliminality", subliminality);
            cognitive.put("perspectiveProximity", perspectiveProximity);
            cognitive.put("conversationComplexity", conversationComplexity);
            cognitive.put("userResponsiveness", userResponsiveness);
            structure.put("cognitive", cognitive);
            
            // Create empty arrays for different components
            structure.put("knowledge", new JSONObject());
            structure.put("conversations", new JSONArray());
            structure.put("ghostFiles", new JSONArray());
            
            // Add functions object with all functions embedded
            JSONObject functions = new JSONObject();
            
            // Add cognitive functions
            JSONObject cognitiveFunctions = new JSONObject();
            cognitiveFunctions.put("initializeCognitive", "function() { /* Initialize cognitive system */ }");
            cognitiveFunctions.put("processCognitiveInput", "function(input) { /* Process input through cognitive framework */ }");
            cognitiveFunctions.put("addToContextWindow", "function(input) { /* Add input to context window */ }");
            cognitiveFunctions.put("calculateInputParameters", "function(input) { /* Calculate input parameters */ }");
            cognitiveFunctions.put("applyPriorityRetention", "function(input, priorityValue) { /* Apply priority retention */ }");
            cognitiveFunctions.put("applyEvaluationDecisional", "function(input, threshold) { /* Apply evaluation decisional */ }");
            cognitiveFunctions.put("applySubconsciousFilter", "function(input, strength) { /* Apply subconscious filter */ }");
            cognitiveFunctions.put("detectSubliminalPatterns", "function(input) { /* Detect subliminal patterns */ }");
            cognitiveFunctions.put("applyPerspectiveProximity", "function(input, context) { /* Apply perspective proximity */ }");
            cognitiveFunctions.put("updateCognitiveParameters", "function() { /* Update cognitive parameters */ }");
            cognitiveFunctions.put("calculateConversationComplexity", "function() { /* Calculate conversation complexity */ }");
            cognitiveFunctions.put("calculateUserResponsiveness", "function() { /* Calculate user responsiveness */ }");
            functions.put("cognitive", cognitiveFunctions);
            
            // Add compression functions
            JSONObject compressionFunctions = new JSONObject();
            compressionFunctions.put("compressData", "function(data, level) { /* Compress data */ }");
            compressionFunctions.put("decompressData", "function(compressed, level) { /* Decompress data */ }");
            compressionFunctions.put("isCompressed", "function(data) { /* Check if data is compressed */ }");
            compressionFunctions.put("generateCacheKey", "function(data) { /* Generate cache key */ }");
            compressionFunctions.put("pruneCache", "function() { /* Prune cache */ }");
            compressionFunctions.put("compressAndStoreFile", "function(key, data) { /* Compress and store file */ }");
            compressionFunctions.put("retrieveAndDecompressFile", "function(key) { /* Retrieve and decompress file */ }");
            functions.put("compression", compressionFunctions);
            
            // Add knowledge base functions
            JSONObject knowledgeFunctions = new JSONObject();
            knowledgeFunctions.put("loadDomain", "function(domainName) { /* Load knowledge domain */ }");
            knowledgeFunctions.put("getKnowledge", "function(domainName, topic) { /* Get knowledge */ }");
            knowledgeFunctions.put("getAvailableDomains", "function() { /* Get available domains */ }");
            knowledgeFunctions.put("purgeOldKnowledge", "function() { /* Purge old knowledge */ }");
            functions.put("knowledge", knowledgeFunctions);
            
            // Add voice recognition functions
            JSONObject voiceFunctions = new JSONObject();
            voiceFunctions.put("startVoiceRecognition", "function() { /* Start voice recognition */ }");
            voiceFunctions.put("stopVoiceRecognition", "function() { /* Stop voice recognition */ }");
            voiceFunctions.put("processVoiceCommand", "function(transcript) { /* Process voice command */ }");
            functions.put("voice", voiceFunctions);
            
            // Add screen awareness functions
            JSONObject screenFunctions = new JSONObject();
            screenFunctions.put("updateScreenContext", "function() { /* Update screen context */ }");
            screenFunctions.put("handleScreenResize", "function() { /* Handle screen resize */ }");
            screenFunctions.put("handleScreenScroll", "function() { /* Handle screen scroll */ }");
            screenFunctions.put("handleMouseMovement", "function(event) { /* Handle mouse movement */ }");
            screenFunctions.put("handleUserInteraction", "function() { /* Handle user interaction */ }");
            screenFunctions.put("adaptInterfaceToScreen", "function() { /* Adapt interface to screen */ }");
            functions.put("screen", screenFunctions);
            
            // Add main system functions
            JSONObject systemFunctions = new JSONObject();
            systemFunctions.put("initializeSystem", "function() { /* Initialize system */ }");
            systemFunctions.put("handleUserInput", "function() { /* Handle user input */ }");
            systemFunctions.put("processInput", "function(text) { /* Process input */ }");
            systemFunctions.put("generateResponse", "function(input) { /* Generate response */ }");
            systemFunctions.put("createGhostFile", "function(content) { /* Create ghost file */ }");
            systemFunctions.put("cleanupGhostFiles", "function() { /* Cleanup ghost files */ }");
            functions.put("system", systemFunctions);
            
            // Add functions to structure
            structure.put("functions", functions);
            
            Log.d(TAG, "Default structure created");
            
            // Save to database
            saveToDatabase();
        } catch (JSONException e) {
            Log.e(TAG, "Error creating default structure: " + e.getMessage());
        }
    }
    
    private void loadParametersFromStructure() {
        try {
            if (structure.has("cognitive")) {
                JSONObject cognitive = structure.getJSONObject("cognitive");
                contextWindowSize = cognitive.optDouble("contextWindowSize", contextWindowSize);
                priorityRetention = cognitive.optDouble("priorityRetention", priorityRetention);
                evaluationThreshold = cognitive.optDouble("evaluationThreshold", evaluationThreshold);
                subliminality = cognitive.optDouble("subliminality", subliminality);
                perspectiveProximity = cognitive.optDouble("perspectiveProximity", perspectiveProximity);
                conversationComplexity = cognitive.optDouble("conversationComplexity", conversationComplexity);
                userResponsiveness = cognitive.optDouble("userResponsiveness", userResponsiveness);
            }
        } catch (JSONException e) {
            Log.e(TAG, "Error loading parameters from structure: " + e.getMessage());
        }
    }
    
    private void updateParametersInStructure() {
        try {
            if (!structure.has("cognitive")) {
                structure.put("cognitive", new JSONObject());
            }
            JSONObject cognitive = structure.getJSONObject("cognitive");
            cognitive.put("contextWindowSize", contextWindowSize);
            cognitive.put("priorityRetention", priorityRetention);
            cognitive.put("evaluationThreshold", evaluationThreshold);
            cognitive.put("subliminality", subliminality);
            cognitive.put("perspectiveProximity", perspectiveProximity);
            cognitive.put("conversationComplexity", conversationComplexity);
            cognitive.put("userResponsiveness", userResponsiveness);
        } catch (JSONException e) {
            Log.e(TAG, "Error updating parameters in structure: " + e.getMessage());
        }
    }
    
    private void saveToDatabase() {
        if (structure != null) {
            databaseManager.saveSystemState(structure.toString());
        }
    }
    
    // Process input through the embedded cognitive algorithm
    public String processInput(String input) {
        try {
            // Add to conversations array
            if (!structure.has("conversations")) {
                structure.put("conversations", new JSONArray());
            }
            JSONArray conversations = structure.getJSONArray("conversations");
            JSONObject newConversation = new JSONObject();
            newConversation.put("input", input);
            newConversation.put("timestamp", System.currentTimeMillis());
            
            // Apply cognitive processing
            double inputPriority = calculateInputPriority(input);
            boolean passesEvaluation = evaluateInput(input);
            JSONObject cognitiveResults = new JSONObject();
            cognitiveResults.put("priority", inputPriority);
            cognitiveResults.put("passesEvaluation", passesEvaluation);
            cognitiveResults.put("complexityFactor", conversationComplexity);
            cognitiveResults.put("responsivenessFactor", userResponsiveness);
            newConversation.put("cognitive", cognitiveResults);
            
            // Generate response
            String response = generateResponse(input, cognitiveResults);
            newConversation.put("response", response);
            
            // Add to conversations array (limit to contextWindowSize)
            conversations.put(newConversation);
            while (conversations.length() > contextWindowSize) {
                // Remove oldest conversation (index 0)
                JSONArray newConversations = new JSONArray();
                for (int i = 1; i < conversations.length(); i++) {
                    newConversations.put(conversations.get(i));
                }
                structure.put("conversations", newConversations);
                conversations = newConversations;
            }
            
            // Update cognitive parameters based on this interaction
            updateCognitiveParameters(input, response);
            
            // Save updated structure to database
            saveToDatabase();
            
            // Save conversation to database
            databaseManager.saveConversation(input, response, conversationComplexity, inputPriority);
            
            return response;
        } catch (JSONException e) {
            Log.e(TAG, "Error processing input: " + e.getMessage());
            return "I'm sorry, I encountered an error processing your input.";
        }
    }
    
    private double calculateInputPriority(String input) {
        // Simple implementation - more complex in real system
        double lengthFactor = Math.min(1.0, input.length() / 100.0);
        double questionFactor = input.contains("?") ? 0.3 : 0.0;
        double exclamationFactor = input.contains("!") ? 0.2 : 0.0;
        
        return Math.min(1.0, (lengthFactor + questionFactor + exclamationFactor) * priorityRetention);
    }
    
    private boolean evaluateInput(String input) {
        // Simple implementation - more complex in real system
        return input.length() >= 3 && evaluationThreshold <= 0.7;
    }
    
    private String generateResponse(String input, JSONObject cognitiveResults) throws JSONException {
        // In a real implementation, this would use the embedded functions in the JSON structure
        // Here we'll use a simple response generation
        
        boolean passesEvaluation = cognitiveResults.getBoolean("passesEvaluation");
        if (!passesEvaluation) {
            return "I need more information to respond properly.";
        }
        
        double priority = cognitiveResults.getDouble("priority");
        String response;
        
        if (input.toLowerCase().contains("hello") || input.toLowerCase().contains("hi")) {
            response = "Hello! How can I help you today?";
        } else if (input.toLowerCase().contains("how are you")) {
            response = "I'm functioning well, thank you for asking!";
        } else if (input.toLowerCase().contains("your name")) {
            response = "I'm Minnie, a self-contained AI system with embedded cognitive processing.";
        } else if (input.toLowerCase().contains("ghost file") || input.toLowerCase().contains("ghostfile")) {
            createGhostFile("Ghost file requested about: " + input);
            response = "I've created a ghost file about this topic.";
        } else if (input.toLowerCase().contains("knowledge") || input.toLowerCase().contains("domain")) {
            response = "I have knowledge domains for arts, history, science, and technology.";
        } else if (input.toLowerCase().contains("structure")) {
            response = "My structure contains " + countStructureElements() + " elements with embedded cognitive parameters.";
        } else if (input.toLowerCase().contains("cognitive")) {
            response = "My cognitive parameters include a context window size of " + contextWindowSize + 
                    " and priority retention of " + priorityRetention + ".";
        } else {
            if (priority > 0.7) {
                response = "That's an important question. I'm processing it with high priority...";
            } else if (priority > 0.4) {
                response = "I understand your question and I'm thinking about it...";
            } else {
                response = "I'm analyzing your input with standard processing...";
            }
            
            // Append a generic response
            response += " Based on my analysis, I would suggest exploring this topic further.";
        }
        
        return response;
    }
    
    private void updateCognitiveParameters(String input, String response) {
        // Update conversation complexity
        double newComplexity = (input.length() + response.length()) / 200.0;
        newComplexity = Math.min(1.0, newComplexity);
        conversationComplexity = (conversationComplexity * 0.8) + (newComplexity * 0.2);
        
        // Update user responsiveness
        double inputFactor = Math.min(1.0, input.length() / 50.0);
        userResponsiveness = (userResponsiveness * 0.9) + (inputFactor * 0.1);
        
        // Update parameters in structure
        updateParametersInStructure();
    }
    
    private void createGhostFile(String content) {
        // Save ghost file to database
        databaseManager.saveGhostFile(content, "conversation");
        
        // Add to structure
        try {
            if (!structure.has("ghostFiles")) {
                structure.put("ghostFiles", new JSONArray());
            }
            JSONArray ghostFiles = structure.getJSONArray("ghostFiles");
            JSONObject ghostFile = new JSONObject();
            ghostFile.put("content", content);
            ghostFile.put("created", System.currentTimeMillis());
            ghostFile.put("type", "conversation");
            ghostFiles.put(ghostFile);
        } catch (JSONException e) {
            Log.e(TAG, "Error creating ghost file in structure: " + e.getMessage());
        }
    }
    
    private int countStructureElements() {
        int count = 0;
        try {
            // Count all keys at all levels recursively
            count = countJsonElements(structure);
        } catch (Exception e) {
            Log.e(TAG, "Error counting structure elements: " + e.getMessage());
        }
        return count;
    }
    
    private int countJsonElements(JSONObject jsonObject) throws JSONException {
        int count = jsonObject.length();
        
        Iterator<String> keys = jsonObject.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            Object value = jsonObject.get(key);
            
            if (value instanceof JSONObject) {
                count += countJsonElements((JSONObject) value);
            } else if (value instanceof JSONArray) {
                count += countJsonArrayElements((JSONArray) value);
            }
        }
        
        return count;
    }
    
    private int countJsonArrayElements(JSONArray jsonArray) throws JSONException {
        int count = jsonArray.length();
        
        for (int i = 0; i < jsonArray.length(); i++) {
            Object value = jsonArray.get(i);
            
            if (value instanceof JSONObject) {
                count += countJsonElements((JSONObject) value);
            } else if (value instanceof JSONArray) {
                count += countJsonArrayElements((JSONArray) value);
            }
        }
        
        return count;
    }
    
    // Getter for the current structure
    public JSONObject getStructure() {
        return structure;
    }
    
    // Getters and setters for cognitive parameters
    public double getContextWindowSize() {
        return contextWindowSize;
    }
    
    public void setContextWindowSize(double contextWindowSize) {
        this.contextWindowSize = contextWindowSize;
        updateParametersInStructure();
        saveToDatabase();
    }
    
    public double getPriorityRetention() {
        return priorityRetention;
    }
    
    public void setPriorityRetention(double priorityRetention) {
        this.priorityRetention = priorityRetention;
        updateParametersInStructure();
        saveToDatabase();
    }
    
    public double getEvaluationThreshold() {
        return evaluationThreshold;
    }
    
    public void setEvaluationThreshold(double evaluationThreshold) {
        this.evaluationThreshold = evaluationThreshold;
        updateParametersInStructure();
        saveToDatabase();
    }
    
    public double getSubliminality() {
        return subliminality;
    }
    
    public void setSubliminality(double subliminality) {
        this.subliminality = subliminality;
        updateParametersInStructure();
        saveToDatabase();
    }
    
    public double getPerspectiveProximity() {
        return perspectiveProximity;
    }
    
    public void setPerspectiveProximity(double perspectiveProximity) {
        this.perspectiveProximity = perspectiveProximity;
        updateParametersInStructure();
        saveToDatabase();
    }
}
