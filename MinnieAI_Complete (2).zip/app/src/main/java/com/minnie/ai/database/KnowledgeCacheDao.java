package com.minnie.ai.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

/**
 * Data Access Object for KnowledgeCache entity
 */
@Dao
public interface KnowledgeCacheDao {
    
    @Insert
    void insert(KnowledgeCache knowledgeCache);
    
    @Query("SELECT * FROM KnowledgeCache WHERE domain = :domain LIMIT 1")
    KnowledgeCache getKnowledgeCache(String domain);
    
    @Query("UPDATE KnowledgeCache SET lastAccessed = :timestamp WHERE domain = :domain")
    void updateLastAccessed(String domain, long timestamp);
    
    @Query("DELETE FROM KnowledgeCache WHERE lastAccessed < :thresholdTime")
    void deleteOldCaches(long thresholdTime);
}
