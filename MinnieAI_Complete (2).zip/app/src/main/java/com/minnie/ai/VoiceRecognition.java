package com.minnie.ai;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Handles voice recognition functionality
 */
public class VoiceRecognition {
    private static final String TAG = "VoiceRecognition";
    
    private final Context context;
    private SpeechRecognizer speechRecognizer;
    private boolean isListening = false;
    private VoiceCallback callback;
    
    // Intent recognition patterns
    private final Map<String, Pattern> intentPatterns = new HashMap<>();
    
    public interface VoiceCallback {
        void onVoiceResult(String text);
        void onVoiceIntent(String intent, Map<String, String> params);
        void onVoiceError(String error);
    }
    
    public VoiceRecognition(Context context) {
        this.context = context;
        
        // Initialize intent patterns
        intentPatterns.put("search", Pattern.compile("(?:search|find|look up)\\s+(?:for\\s+)?(.+)", Pattern.CASE_INSENSITIVE));
        intentPatterns.put("open", Pattern.compile("(?:open|launch|start)\\s+(.+)", Pattern.CASE_INSENSITIVE));
        intentPatterns.put("create", Pattern.compile("(?:create|make|new)\\s+(?:a\\s+)?(.+)", Pattern.CASE_INSENSITIVE));
        intentPatterns.put("set", Pattern.compile("(?:set|change)\\s+(.+?)\\s+(?:to|as)\\s+(.+)", Pattern.CASE_INSENSITIVE));
        intentPatterns.put("help", Pattern.compile("(?:help|assist|aid)(?:\\s+(?:me|with|on)\\s+(.+))?", Pattern.CASE_INSENSITIVE));
        
        initializeSpeechRecognizer();
    }
    
    private void initializeSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context);
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override
                public void onReadyForSpeech(Bundle bundle) {
                    Log.d(TAG, "Ready for speech");
                }
                
                @Override
                public void onBeginningOfSpeech() {
                    Log.d(TAG, "Beginning of speech");
                }
                
                @Override
                public void onRmsChanged(float v) {
                    // Voice amplitude changed
                }
                
                @Override
                public void onBufferReceived(byte[] bytes) {
                    // Buffer received
                }
                
                @Override
                public void onEndOfSpeech() {
                    Log.d(TAG, "End of speech");
                    isListening = false;
                }
                
                @Override
                public void onError(int i) {
                    isListening = false;
                    String errorMessage;
                    switch (i) {
                        case SpeechRecognizer.ERROR_AUDIO:
                            errorMessage = "Audio recording error";
                            break;
                        case SpeechRecognizer.ERROR_CLIENT:
                            errorMessage = "Client side error";
                            break;
                        case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                            errorMessage = "Insufficient permissions";
                            break;
                        case SpeechRecognizer.ERROR_NETWORK:
                            errorMessage = "Network error";
                            break;
                        case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                            errorMessage = "Network timeout";
                            break;
                        case SpeechRecognizer.ERROR_NO_MATCH:
                            errorMessage = "No match found";
                            break;
                        case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                            errorMessage = "RecognitionService busy";
                            break;
                        case SpeechRecognizer.ERROR_SERVER:
                            errorMessage = "Server error";
                            break;
                        case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                            errorMessage = "No speech input";
                            break;
                        default:
                            errorMessage = "Unknown error";
                            break;
                    }
                    Log.e(TAG, "Error: " + errorMessage);
                    if (callback != null) {
                        callback.onVoiceError(errorMessage);
                    }
                }
                
                @Override
                public void onResults(Bundle bundle) {
                    ArrayList<String> results = bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (results != null && !results.isEmpty()) {
                        String text = results.get(0);
                        Log.d(TAG, "Voice result: " + text);
                        
                        if (callback != null) {
                            callback.onVoiceResult(text);
                            
                            // Check for intents
                            Map.Entry<String, Map<String, String>> intent = detectIntent(text);
                            if (intent != null) {
                                callback.onVoiceIntent(intent.getKey(), intent.getValue());
                            }
                        }
                    }
                }
                
                @Override
                public void onPartialResults(Bundle bundle) {
                    // Partial results
                }
                
                @Override
                public void onEvent(int i, Bundle bundle) {
                    // Event
                }
            });
        } else {
            Log.e(TAG, "Speech recognition not available on this device");
        }
    }
    
    public void startListening(VoiceCallback callback) {
        if (!isListening && speechRecognizer != null) {
            this.callback = callback;
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
            intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.getPackageName());
            
            try {
                isListening = true;
                speechRecognizer.startListening(intent);
            } catch (Exception e) {
                isListening = false;
                Log.e(TAG, "Error starting speech recognition: " + e.getMessage());
                if (callback != null) {
                    callback.onVoiceError("Error starting speech recognition: " + e.getMessage());
                }
            }
        }
    }
    
    public void stopListening() {
        if (isListening && speechRecognizer != null) {
            speechRecognizer.stopListening();
            isListening = false;
        }
    }
    
    public boolean isListening() {
        return isListening;
    }
    
    private Map.Entry<String, Map<String, String>> detectIntent(String text) {
        for (Map.Entry<String, Pattern> entry : intentPatterns.entrySet()) {
            String intent = entry.getKey();
            Pattern pattern = entry.getValue();
            
            Matcher matcher = pattern.matcher(text);
            if (matcher.find()) {
                Map<String, String> params = new HashMap<>();
                
                switch (intent) {
                    case "search":
                        if (matcher.groupCount() >= 1) {
                            params.put("query", matcher.group(1));
                        }
                        break;
                    case "open":
                        if (matcher.groupCount() >= 1) {
                            params.put("target", matcher.group(1));
                        }
                        break;
                    case "create":
                        if (matcher.groupCount() >= 1) {
                            params.put("item", matcher.group(1));
                        }
                        break;
                    case "set":
                        if (matcher.groupCount() >= 2) {
                            params.put("setting", matcher.group(1));
                            params.put("value", matcher.group(2));
                        }
                        break;
                    case "help":
                        if (matcher.groupCount() >= 1 && matcher.group(1) != null) {
                            params.put("topic", matcher.group(1));
                        }
                        break;
                }
                
                return new Map.Entry<String, Map<String, String>>() {
                    @Override
                    public String getKey() {
                        return intent;
                    }
                    
                    @Override
                    public Map<String, String> getValue() {
                        return params;
                    }
                    
                    @Override
                    public Map<String, String> setValue(Map<String, String> value) {
                        throw new UnsupportedOperationException();
                    }
                };
            }
        }
        
        return null;
    }
    
    public void destroy() {
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
    }
}
