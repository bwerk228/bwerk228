package com.minnie.ai.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

/**
 * Data Access Object for GhostFile entity
 */
@Dao
public interface GhostFileDao {
    
    @Insert
    void insert(GhostFile ghostFile);
    
    @Query("SELECT * FROM GhostFile WHERE type = :type ORDER BY created DESC")
    List<GhostFile> getGhostFilesByType(String type);
    
    @Query("DELETE FROM GhostFile WHERE created < :thresholdTime")
    void deleteOldGhostFiles(long thresholdTime);
}
