package com.minnie.ai.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Entity class representing a knowledge cache entry in the database
 */
@Entity
public class KnowledgeCache {
    @PrimaryKey(autoGenerate = true)
    public int id;
    
    public String domain;
    public String data;
    public int compressionLevel;
    public long lastAccessed;
}
